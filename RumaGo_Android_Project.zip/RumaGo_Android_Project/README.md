# RumaGo Android MVP – Project Source

Ini adalah project Android Studio (Kotlin + WebView) dengan antarmuka belanja RumaGo yang berjalan dari aset lokal.

## Cara membuat APK
1. Ekstrak ZIP ini.
2. Buka Android Studio, pilih **Open**, lalu pilih folder `RumaGo_Android_Project`.
3. Tunggu Gradle Sync selesai. Gunakan Android SDK 35 dan JDK 17.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur demo
- Katalog produk, pencarian dan kategori.
- Keranjang dan hitung total.
- Form checkout demo.
- Riwayat pesanan lokal pada perangkat.
- Tampilan mobile Android.

## Batasan penting
Versi ini belum terhubung ke backend/server. Pesanan hanya tersimpan di perangkat yang digunakan. Belum ada login sungguhan, sinkronisasi antarperangkat, stok real-time, pembayaran Midtrans/Xendit, notifikasi, GPS kurir, atau dashboard admin online. Jangan gunakan untuk menerima pembayaran atau pesanan pelanggan sungguhan sebelum backend, keamanan, dan operasional diuji.
